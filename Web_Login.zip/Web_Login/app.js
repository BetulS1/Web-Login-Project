// KULLANILAN KÜTÜPHANELERİ EKLİYORUZ
const express = require("express");
const mysql = require("mysql"); 
const dotenv = require("dotenv"); 
const path = require("path");

//express kullanmak için
const index = express();
//oturum açma bilgilerini tutmak için(session)
var expressSession = require('express-session');
index.use(expressSession({secret: 'your secret', saveUninitialized: true, resave: false}));

//veritabanı bilgilerini daha sağlıklı tutumak için kullanılan dosyanın yolunu belirtiyoruz 
dotenv.config({ path:'./.env'});

//veritabanı bilgileri 
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST, 
    user: process.env.DATABASE_USER,
    password:process.env.DATABASE_PASSWORD,
    database:process.env.DATABASE 
});
//veritabanı bağlantısı
db.connect( (error) => {
    if(error){
        console.log(error)
    }else{
        console.log("Mysql Connected!")
    }
})
//css js ve bootstrap gibi görünüm dosyalarının bulunduğu ana klasör static tanımlandı
index.use('/static',express.static(path.join(__dirname, 'public')))
//json ve post verileri için
index.use(express.urlencoded({extended: false}));
//url yönlendirmeleri için 
index.use('/auth', require('./routes/auth'));
index.use('/', require('./routes/pages'));
//kullanılan görünüm yöntemini tanımladık
index.set('view engine', 'hbs');


//localhost server başlatmak için
index.listen(3001,() => {
    console.log("Server Started On Port 3001 !");
    // http://localhost:3001/
});
