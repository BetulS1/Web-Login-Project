//post edilen bilgiler nereye gönderilecek? Yönlendirme yapılıyor
const express = require("express")
const authControllers = require('../controllers/auth');
const authLoginControllers = require('../controllers/login');
const router = express.Router();
router.post('/kayit', authControllers.kayit)
router.post('/index', authLoginControllers.index)

module.exports = router;