//url yönlendirmeleri
const express = require("express")
const router = express.Router();

 router.get('/', (req,res) => {
     res.render("index");
 });

router.get('/kayit', (req,res) => {
    res.render("kayit");
});

//çıkış yapan kullanıcının oturumunu kapatıyoruz
router.get('/logout',(req,res) => {
    req.session.destroy();
    return res.render('index', {
        message: "Oturum Kapatıldı!"
    });
});
 module.exports =router;