//veritabanı bağlantıları yapılıyor
const mysql = require("mysql");
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

//post ile gelen verileri alıyor ve veritabanına kullanıcıyı kaydediyoruz
exports.kayit = (req, res) => {
    const { kullanici, eposta, sifre } = req.body;
    db.query("SELECT eposta FROM kullanici WHERE eposta= ? ", [eposta], (error, results) => {
        if (error) {
            console.log(error);
        }
        if (results.length > 0) {
            return res.render('kayit', {
                message: "Hesap mevcut"
            });
        } else {
            db.query("INSERT INTO kullanici SET ?", { kullanici: kullanici, eposta: eposta, sifre: sifre }, (error, results) => {
                if (error) {
                    console.log(error);
                } else {
                    console.log(results);
                    return res.render('kayit', {
                        message: "Kayıt yapıldı"
                    });
                }
            })
        }
    });
    console.log(req.body);
}