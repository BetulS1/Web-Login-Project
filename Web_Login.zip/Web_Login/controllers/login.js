//veritabanı ve oturum bilgileri için kütüphanleri ekledik
const mysql = require("mysql");
const express = require("express");
const cookieParser = require("cookie-parser");
const sessions = require('express-session');
const index = express();
//oturum için 
index.use(cookieParser());
//veritabanı bağlantısı 
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});
//açılan oturum bilgilerinin tutulma süresi
const oneDay = 1000 * 60 * 60 * 24;
//giriş yapan kullanıcının oturum bilgilerini tutuyoruz
index.use(sessions({
    secret: "yazilim yazilim asdtuorytemklsp",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false 
}));
//giriş yapmak isteyen kullanıcı kayıtlı mı kontrolleri ve ana sayfaya yönlendirme
exports.index = (req, res) => {
    const { eposta, sifre } = req.body;
    db.query("SELECT kullanici,eposta,sifre FROM kullanici WHERE eposta= ? AND sifre= ? ", [eposta,sifre], (error, results) => {
        if (error) {
            console.log(error);
        }
        if (results.length == 0) {
            return res.render('index', {
                message: "Eposta veya Şifre Hatalı!"
            });

        } else {
            session=req.session;
            session.userid=req.body.eposta;
            console.log(req.session)
            return res.render('home',{
                message: " Oturum Açıldı",
                kullanici:results[0].kullanici,
                eposta:eposta
            });
        }
    });

    console.log(req.body);
}